package altYapi.seleniumGauge.test;

import org.slf4j.LoggerFactory;
import org.slf4j.impl.Log4jLoggerAdapter;

public class DenemeTest{

    private static Log4jLoggerAdapter logger = (Log4jLoggerAdapter) LoggerFactory.getLogger(DenemeTest.class);

    public DenemeTest() {

    }

   // @Test
    public void denemeeee(){

        System.out.println("Deneme");
        //StoreHelper.INSTANCE.duplicateKeyControl(true);
    }


}
